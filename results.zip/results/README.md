# Frozen result map

These directories contain the numerical evidence retained for the manuscript:

| Directory | System and scope | Test size |
|---|---|---:|
| `rbts_stress_n1000/` | RBTS stress-conditioned common-state replay before the wind-acceptance reduction | 1000 |
| `rbts_unconditional_n500/` | RBTS equal-hour adequacy replay before the wind-acceptance reduction | 500 |
| `rts79_stress_n500/` | RTS79 stress-conditioned common-state replay before the wind-acceptance reduction | 500 |
| `rts79_unconditional_n500/` | RTS79 equal-hour adequacy replay before the wind-acceptance reduction | 500 |
| `wind_acceptance_corrected/` | Common acceptance correction and the final reduced summaries used by the paper | same states |
| `artifacts/` | Frozen parameter/resource locks and component-state draws | n/a |

For each base replay, the shard CSV files are the raw model outputs, `analysis/*_long.csv` is the state-model panel, and `analysis/*_summary.csv` is the model-level reduction. The unconditional `hybrid_analysis/` directories contain the equal-hour adequacy summaries used for EDNS, LOLP, and annualized EUE.

The receipts and manifests retain SHA-256 hashes and the original run paths as immutable provenance fields. Those absolute paths record the machine on which the experiment was executed; repository relocation does not alter the accompanying data or hashes.

The correction workflow originally wrote a `corrected_inputs/*_long.csv` copy before reduction. Each copy was byte-identical to the corresponding retained `analysis/*_long.csv`, so the duplicate copies are omitted from the repository. Running `postprocess/rebuild_test_wind_corrected_results.ps1` in a new output directory recreates the complete intermediate chain.

For paper-facing compact tables and claims, see `../../paper/results/`.
